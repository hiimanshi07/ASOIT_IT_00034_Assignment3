$(document).ready(function() {
  $('#feedbackForm').submit(function(event) {
    event.preventDefault(); // Prevent the default form submission
    
    // Get the form data
    var formData = {
      name: $('#name').val(),
      email: $('#email').val(),
      message: $('#message').val()
    };
    
    // Send the form data to the server (you can customize this part as needed)

  });
});
$(document).ready(function() {
  $('#feedbackForm').submit(function(event)
  {
    alert('Record saved successfully !');
  });
});

