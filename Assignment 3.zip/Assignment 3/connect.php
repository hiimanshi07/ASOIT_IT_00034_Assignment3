<?php
        $servername = 'localhost';
        $database = "assign_3";
        $username = "root";
        $password = "";

        $conn =  mysqli_connect($servername, $username,$password, $database);
        
        //  check connection
        if (!$conn) {
            die('Connection failed: ' .mysqli_connect_error());
        }
        // insert value
        $name = $_POST['name'];
        $email = $_POST['email'];
        $Message = $_POST['Message'];

    

        $sql = "INSERT INTO feedback (name, email, Message) VALUES ('$name', '$email', '$Message')";

        if (mysqli_query($conn , $sql)) {
            echo "Thank you for your feedback!";
        } else {
            echo "Error: ".mysqli_error($conn) ;
        }

        mysqli_close($conn);
    
?>